package com.example.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {

    // Приложения, которые сами попадут в избранное при первом запуске (если установлены)
    private static final String[] DEFAULT_FAVS = {
            "org.smarttube.stable", "org.smarttube.beta", "com.liskovsoft.smarttubetv.beta",
            "org.xbmc.kodi", "org.videolan.vlc", "com.mxtech.videoplayer.ad",
            "com.esaba.downloader", "com.android.tv.settings", "com.android.settings"
    };

    private static final int FOCUS_NONE = -1;
    private static final int FOCUS_ALL = -2;
    private static final int REQ_STORAGE = 1;
    private static final String LIST_FAVS = "favs";
    private static final String LIST_HIDDEN = "hidden";
    private static final int ICON_PX = 96;

    private static boolean autoDone = false; // автозапуск срабатывает один раз за процесс

    private static class App {
        String label;
        String pkg;
        Drawable icon;
        ActivityInfo ai;
        Intent intent;
        int color;
        boolean system;
    }

    private Cfg cfg;
    private PackageManager pm;
    private float u; // 1 условная единица = 1% ширины экрана

    private FrameLayout root;
    private FrameLayout home;
    private FrameLayout gear;
    private BgView bg;
    private LinearLayout top;
    private LinearLayout row;
    private TextClock clock;
    private TextClock date;
    private TextView info;
    private HorizontalScrollView rowScroll;
    private TextView hint;
    private LinearLayout allOverlay;
    private FrameLayout settingsOverlay;
    private Widgets.RamGauge ramGauge;
    private TextView ramSub;

    private final Map<String, TextView> stars = new HashMap<String, TextView>();
    private final Map<String, Drawable> bannerCache = new HashMap<String, Drawable>();
    private final List<App> apps = new ArrayList<App>();
    private Bitmap wallpaper;
    private String lastSig = "";
    private boolean firstStart = true;
    private boolean lastNight = false;
    private volatile boolean loading = false;
    private volatile boolean photoLoading = false;
    private volatile boolean weatherLoading = false;

    // Текущий внешний вид (читается из настроек)
    private int perf, tileW, tileH, tileGap, borderColor, accent, tintMode, focusMs;
    private float tileRad, focusScale;
    private boolean useBanners, useLabels, shadows;

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { loadApps(); }
    };

    // ================================================================ старт

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new Cfg(this);
        pm = getPackageManager();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        u = dm.widthPixels / 100f;
        readLook();
        buildUi();
        applyRowPos();
        applyClock();
        updateBg();
        if (idx(Cfg.BGSTYLE, 7) >= 4) loadPhoto(false, false);
        loadApps();
        maybeAutoWallpaper(true);
    }

    private int px(float units) { return Math.round(units * u); }

    private int idx(String key, int len) {
        return Math.max(0, Math.min(len - 1, cfg.get(key)));
    }

    private TextView text(String s, float sizeU, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void safeStart(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("Не удалось открыть"); }
    }

    private static int mix(int color, int base, float t) {
        int r = Math.round(Color.red(color) * t + Color.red(base) * (1 - t));
        int g = Math.round(Color.green(color) * t + Color.green(base) * (1 - t));
        int b = Math.round(Color.blue(color) * t + Color.blue(base) * (1 - t));
        return Color.rgb(r, g, b);
    }

    // Чёрный или белый текст в зависимости от яркости фона
    private static int textOn(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.72 ? 0xFF101010 : Color.WHITE;
    }

    // ================================================== чтение настроек вида

    private void readLook() {
        float[] widths = {16f, 19.5f, 23f};
        float[] ratios = {0.5625f, 0.75f, 1f};
        float[] rads = {0.2f, 0.7f, 1.1f, 2.0f};
        float[] gaps = {0.6f, 1.2f, 2.0f};
        float[] scales = {1f, 1.04f, 1.08f, 1.14f};
        int[] anims = {80, 120, 220, 0};

        perf = idx(Cfg.PERF, 3);
        tileW = px(widths[idx(Cfg.TILE_SIZE, 3)]);
        tileH = Math.round(tileW * ratios[idx(Cfg.TILE_RATIO, 3)]);
        tileRad = rads[idx(Cfg.TILE_ROUND, 4)] * u;
        tileGap = px(gaps[idx(Cfg.TILE_GAP, 3)]);
        focusScale = scales[idx(Cfg.FOCUS_SCALE, 4)];
        focusMs = anims[idx(Cfg.FOCUS_ANIM, 4)];
        accent = Cfg.ACCENTS[idx(Cfg.ACCENT, Cfg.ACCENTS.length)];

        int fb = idx(Cfg.FOCUS_BORDER, 3);
        borderColor = fb == 0 ? 0 : (fb == 1 ? 0xFFFFFFFF : accent);
        useBanners = idx(Cfg.TILE_BANNERS, 2) == 0;
        useLabels = idx(Cfg.TILE_LABELS, 2) == 0;
        tintMode = idx(Cfg.TILE_TINT, 3);
        shadows = perf == 0;

        // Режимы производительности для слабых приставок
        if (perf >= 1) focusMs = Math.min(focusMs, 80);
        if (perf == 2) {
            focusScale = 1f;
            focusMs = 0;
            useBanners = false;
        }
    }

    // =============================================================== главный экран

    private void buildUi() {
        root = new FrameLayout(this);
        home = new FrameLayout(this);
        root.addView(home, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bg = new BgView(this);
        home.addView(bg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Часы, дата и строка информации
        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        clock = new TextClock(this);
        clock.setTextColor(Color.WHITE);
        top.addView(clock);
        date = new TextClock(this);
        date.setFormat24Hour("EEEE, d MMMM");
        date.setFormat12Hour("EEEE, d MMMM");
        date.setTextColor(0xB3FFFFFF);
        top.addView(date);
        info = new TextView(this);
        info.setTextColor(0xCCFFFFFF);
        info.setSingleLine(true);
        top.addView(info);
        home.addView(top, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START));

        // Ряд избранного
        rowScroll = new HorizontalScrollView(this);
        rowScroll.setHorizontalScrollBarEnabled(false);
        rowScroll.setClipChildren(false);
        rowScroll.setClipToPadding(false);
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        rowScroll.addView(row, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        home.addView(rowScroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        // Подсказка, пока избранное пустое
        hint = text("Откройте «Все приложения» и удерживайте OK на приложении, чтобы добавить его сюда",
                1.6f, 0x99FFFFFF);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        hp.leftMargin = px(5f);
        hp.bottomMargin = px(1f);
        home.addView(hint, hp);
        hint.setVisibility(View.GONE);

        // Кнопка настроек справа сверху
        int gs = px(5f);
        gear = new FrameLayout(this);
        GradientDrawable gbg = new GradientDrawable();
        gbg.setShape(GradientDrawable.OVAL);
        gbg.setColor(0x33FFFFFF);
        gear.setBackground(gbg);
        gear.addView(new Widgets.SlidersIcon(this), new FrameLayout.LayoutParams(
                px(2.6f), px(2.6f), Gravity.CENTER));
        gear.setOnClickListener(v -> openSettings());
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(gs, gs, Gravity.TOP | Gravity.END);
        gp.topMargin = px(3.5f);
        gp.rightMargin = px(3.5f);
        home.addView(gear, gp);
        decorateGear();

        setContentView(root);
    }

    private void decorateGear() { decorate(gear, px(5f) / 2f); }

    private void applyClock() {
        boolean show = idx(Cfg.CLOCK_SHOW, 2) == 0;
        top.setVisibility(show ? View.VISIBLE : View.GONE);

        String f = idx(Cfg.CLOCK_FMT, 2) == 0 ? "HH:mm" : "h:mm";
        clock.setFormat24Hour(f);
        clock.setFormat12Hour(f);

        float[] sizes = {6f, 8.5f, 11f, 14f};
        float sz = sizes[idx(Cfg.CLOCK_SIZE, 4)];
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, sz * u);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.max(1.6f, sz * 0.26f) * u);
        info.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.max(1.5f, sz * 0.21f) * u);

        int ft = idx(Cfg.CLOCK_FONT, 4);
        Typeface tf;
        if (ft == 0) tf = Typeface.create("sans-serif-thin", Typeface.NORMAL);
        else if (ft == 1) tf = Typeface.create("sans-serif-light", Typeface.NORMAL);
        else if (ft == 2) tf = Typeface.create("sans-serif", Typeface.NORMAL);
        else tf = Typeface.create("sans-serif", Typeface.BOLD);
        clock.setTypeface(tf);

        date.setVisibility(idx(Cfg.CLOCK_DATE, 2) == 0 ? View.VISIBLE : View.GONE);

        int pos = idx(Cfg.CLOCK_POS, 3);
        top.setPadding(px(5f), px(3.5f), px(pos == 2 ? 11f : 5f), 0);
        top.setGravity(pos == 0 ? Gravity.START : (pos == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.END));
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) top.getLayoutParams();
        lp.gravity = Gravity.TOP | (pos == 0 ? Gravity.START
                : (pos == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.END));
        top.setLayoutParams(lp);
        applyInfo();
    }

    private void applyRowPos() {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) rowScroll.getLayoutParams();
        int pos = idx(Cfg.ROW_POS, 3);
        lp.gravity = pos == 2 ? Gravity.CENTER_VERTICAL : Gravity.BOTTOM;
        lp.bottomMargin = pos == 0 ? px(3.5f) : (pos == 1 ? px(15f) : 0);
        rowScroll.setLayoutParams(lp);
        int pad = Math.round(tileH * (focusScale - 1f) / 2f) + px(1f);
        rowScroll.setPadding(px(5f), pad, px(5f), pad);
    }

    private void applyLook() {
        readLook();
        applyRowPos();
        decorateGear();
        refreshRow(FOCUS_NONE);
    }

    private void applyAll() {
        applyLook();
        applyClock();
        updateBg();
    }

    private LinearLayout.LayoutParams tileLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, tileH);
        lp.rightMargin = tileGap;
        return lp;
    }

    private void refreshRow(int focusIdx) {
        row.removeAllViews();
        boolean allFirst = idx(Cfg.ALL_POS, 2) == 0;
        boolean tools = idx(Cfg.TILE_TOOLS, 2) == 0;

        if (allFirst) {
            row.addView(makeAllTile(), tileLp());
            if (tools) row.addView(makeRamTile(), tileLp());
        }

        int favCount = 0;
        for (String pkg : cfg.list(LIST_FAVS)) {
            final App a = find(pkg);
            if (a == null) continue;
            favCount++;
            View t = tile(a, tileW, tileH, useBanners);
            t.setTag(a.pkg);
            t.setOnClickListener(v -> launch(a));
            t.setOnLongClickListener(v -> { showAppMenu(a); return true; });
            row.addView(t, tileLp());
        }

        if (!allFirst) {
            if (tools) row.addView(makeRamTile(), tileLp());
            row.addView(makeAllTile(), tileLp());
        }
        hint.setVisibility(favCount == 0 ? View.VISIBLE : View.GONE);

        if (focusIdx != FOCUS_NONE && allOverlay == null && settingsOverlay == null) {
            int count = row.getChildCount();
            int i = focusIdx == FOCUS_ALL ? (allFirst ? 0 : count - 1) : Math.min(focusIdx, count - 1);
            View fv = row.getChildAt(i);
            if (fv != null) fv.requestFocus();
        }
    }

    private void focusTile(String pkg) {
        for (int i = 0; i < row.getChildCount(); i++) {
            View c = row.getChildAt(i);
            if (pkg.equals(c.getTag())) { c.requestFocus(); return; }
        }
    }

    // Плитка приложения: баннер (если есть) или иконка на цветном фоне
    private FrameLayout tile(App a, int w, int h, boolean wantBanner) {
        FrameLayout f = new FrameLayout(this);

        Drawable banner = null;
        if (wantBanner) {
            banner = bannerCache.get(a.pkg);
            if (banner == null) {
                try { banner = a.ai.loadBanner(pm); } catch (Throwable ignored) { }
                if (banner != null) bannerCache.put(a.pkg, banner);
            }
        }

        if (banner != null) {
            f.setBackgroundColor(0xFF10162A);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageDrawable(banner);
            f.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            int base = tintMode == 0 ? a.color : (tintMode == 1 ? 0xFF3A4156 : accent);
            GradientDrawable grad = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{mix(base, 0xFF141A2B, 0.55f), mix(base, 0xFF0B1020, 0.18f)});
            grad.setCornerRadius(tileRad);
            f.setBackground(grad);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            col.setPadding(px(0.8f), 0, px(0.8f), 0);

            int is = Math.round(h * (useLabels ? 0.44f : 0.58f));
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(a.icon);
            col.addView(icon, new LinearLayout.LayoutParams(is, is));

            if (useLabels) {
                TextView lb = new TextView(this);
                lb.setText(a.label);
                lb.setTextColor(Color.WHITE);
                lb.setTextSize(TypedValue.COMPLEX_UNIT_PX, h * 0.13f);
                lb.setSingleLine(true);
                lb.setEllipsize(TextUtils.TruncateAt.END);
                lb.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.topMargin = Math.round(h * 0.06f);
                col.addView(lb, lp);
            }
            f.addView(col, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        decorate(f, tileRad);
        return f;
    }

    // Плитка «Все приложения»
    private FrameLayout makeAllTile() {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable grad = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{accent, mix(accent, 0xFF000000, 0.45f)});
        grad.setCornerRadius(tileRad);
        f.setBackground(grad);

        int fg = textOn(accent);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int is = Math.round(tileH * 0.36f);
        col.addView(new Widgets.GridIcon(this, fg), new LinearLayout.LayoutParams(is, is));

        TextView lb = new TextView(this);
        lb.setText("Все приложения");
        lb.setTextColor(fg);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_PX, tileH * 0.13f);
        lb.setSingleLine(true);
        lb.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Math.round(tileH * 0.07f);
        col.addView(lb, lp);

        f.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        decorate(f, tileRad);
        f.setOnClickListener(v -> openAll());
        f.setOnLongClickListener(v -> { openSettings(); return true; });
        return f;
    }

    // Плитка очистки памяти с кольцом занятой ОЗУ
    private FrameLayout makeRamTile() {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable grad = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{0xFF2B3A55, 0xFF141B2B});
        grad.setCornerRadius(tileRad);
        f.setBackground(grad);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int is = Math.round(tileH * 0.34f);
        ramGauge = new Widgets.RamGauge(this);
        col.addView(ramGauge, new LinearLayout.LayoutParams(is, is));

        TextView lb = new TextView(this);
        lb.setText("Очистить память");
        lb.setTextColor(Color.WHITE);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_PX, tileH * 0.13f);
        lb.setSingleLine(true);
        lb.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Math.round(tileH * 0.06f);
        col.addView(lb, lp);

        ramSub = new TextView(this);
        ramSub.setTextColor(0xAAFFFFFF);
        ramSub.setTextSize(TypedValue.COMPLEX_UNIT_PX, tileH * 0.095f);
        ramSub.setSingleLine(true);
        ramSub.setGravity(Gravity.CENTER);
        col.addView(ramSub, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        f.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        updateRamTile();
        decorate(f, tileRad);
        f.setOnClickListener(v -> cleanMemory());
        return f;
    }

    // Скругление, рамка выбора и увеличение при фокусе
    private void decorate(FrameLayout f, final float rad) {
        f.setFocusable(true);
        f.setClickable(true);
        f.setLongClickable(true);
        f.setClipToOutline(true);
        f.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
            }
        });

        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(Color.TRANSPARENT);
        on.setCornerRadius(rad);
        if (borderColor != 0) on.setStroke(Math.max(2, Math.round(0.3f * u)), borderColor);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        f.setForeground(sl);

        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? focusScale : 1f;
            if (focusMs > 0) {
                v.animate().scaleX(s).scaleY(s).setDuration(focusMs).start();
            } else {
                v.setScaleX(s);
                v.setScaleY(s);
            }
            v.setTranslationZ(has && shadows ? u * 0.8f : 0f);
        });
    }

    // ============================================================ информация

    private static String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h >= 5 && h < 12) return "Доброе утро";
        if (h >= 12 && h < 18) return "Добрый день";
        if (h >= 18 && h < 23) return "Добрый вечер";
        return "Доброй ночи";
    }

    private static String weatherText(int c) {
        if (c == 0) return "Ясно";
        if (c <= 2) return "Малооблачно";
        if (c == 3) return "Пасмурно";
        if (c == 45 || c == 48) return "Туман";
        if (c >= 51 && c <= 57) return "Морось";
        if (c >= 61 && c <= 67) return "Дождь";
        if (c >= 71 && c <= 77) return "Снег";
        if (c >= 80 && c <= 82) return "Ливень";
        if (c == 85 || c == 86) return "Снегопад";
        if (c >= 95) return "Гроза";
        return "";
    }

    private static String fmtTemp(int tenths) {
        int r = Math.round(tenths / 10f);
        return (r > 0 ? "+" : "") + r + "°";
    }

    private static String fmtMem(long bytes) {
        double mb = bytes / 1048576.0;
        if (mb >= 1024) return String.format(Locale.getDefault(), "%.1f ГБ", mb / 1024.0);
        return Math.round(mb) + " МБ";
    }

    private long freeMem() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi.availMem;
    }

    private long totalMem() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi.totalMem;
    }

    private void applyInfo() {
        StringBuilder sb = new StringBuilder();
        if (idx(Cfg.GREETING, 2) == 1) sb.append(greeting());

        int ci = idx(Cfg.WEATHER, Cfg.CITY_NAMES.length + 1);
        if (ci > 0) {
            if (sb.length() > 0) sb.append("  ·  ");
            sb.append(Cfg.CITY_NAMES[ci - 1]);
            if (cfg.getInt("w_city", -1) == ci && cfg.getLong("w_time", 0L) > 0L) {
                sb.append(' ').append(fmtTemp(cfg.getInt("w_temp", 0)))
                  .append(' ').append(weatherText(cfg.getInt("w_code", 0)));
            } else {
                sb.append(" …");
            }
        }
        if (idx(Cfg.RAMSHOW, 2) == 1) {
            if (sb.length() > 0) sb.append("  ·  ");
            sb.append("Свободно ").append(fmtMem(freeMem()));
        }
        info.setText(sb.toString());
        info.setVisibility(sb.length() == 0 ? View.GONE : View.VISIBLE);
    }

    private void updateRamTile() {
        long total = totalMem();
        long free = freeMem();
        if (ramGauge != null && total > 0) ramGauge.setUsed(1f - (float) free / total);
        if (ramSub != null) ramSub.setText(fmtMem(free) + " свободно");
    }

    // Погода с open-meteo.com (без ключей); обновляется не чаще раза в 30 минут
    private void fetchWeather(boolean force) {
        final int ci = idx(Cfg.WEATHER, Cfg.CITY_NAMES.length + 1);
        if (ci == 0 || weatherLoading) return;
        final long now = System.currentTimeMillis();
        if (!force && cfg.getInt("w_city", -1) == ci
                && now - cfg.getLong("w_time", 0L) < 30L * 60L * 1000L) return;
        weatherLoading = true;
        final double lat = Cfg.CITY_LAT[ci - 1];
        final double lon = Cfg.CITY_LON[ci - 1];
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String s = Net.getString("https://api.open-meteo.com/v1/forecast?latitude="
                            + lat + "&longitude=" + lon + "&current_weather=true");
                    JSONObject cw = new JSONObject(s).getJSONObject("current_weather");
                    cfg.putInt("w_temp", (int) Math.round(cw.getDouble("temperature") * 10.0));
                    cfg.putInt("w_code", cw.getInt("weathercode"));
                    cfg.putInt("w_city", ci);
                    cfg.putLong("w_time", now);
                } catch (Throwable ignored) { }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        weatherLoading = false;
                        applyInfo();
                    }
                });
            }
        }).start();
    }

    // Очистка оперативной памяти: останавливает фоновые процессы приложений
    private void cleanMemory() {
        final long before = freeMem();
        final List<String> pkgs = new ArrayList<String>();
        for (App a : apps) pkgs.add(a.pkg);
        toast("Очистка памяти…");
        new Thread(new Runnable() {
            @Override public void run() {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                for (String p : pkgs) {
                    if (p.equals(getPackageName())) continue;
                    try { am.killBackgroundProcesses(p); } catch (Throwable ignored) { }
                }
                try { Thread.sleep(900); } catch (InterruptedException ignored) { }
                final long after = freeMem();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        long diff = Math.max(0L, after - before);
                        toast("Свободно " + fmtMem(after)
                                + (diff > 0 ? " (+" + fmtMem(diff) + ")" : ""));
                        applyInfo();
                        updateRamTile();
                    }
                });
            }
        }).start();
    }

    // =================================================================== фон

    private static boolean isNight() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h >= 22 || h < 7;
    }

    private void updateBg() {
        int th = idx(Cfg.THEME, Cfg.THEME_BG.length);
        int st = idx(Cfg.BGSTYLE, 7);
        if (perf == 2 && st != 2) st = 1; // минимальный режим: только простой фон
        float[] muls = {0.5f, 1f, 1.6f};
        int[] dims = {0, 20, 40, 60};
        int dim = dims[idx(Cfg.BGDIM, 4)];
        lastNight = isNight();
        if (idx(Cfg.NIGHT, 2) == 1 && lastNight) dim = Math.max(dim, 45);
        int ds = perf == 0 ? 2 : 4;

        bg.apply(st, Cfg.THEME_BG[th], Cfg.THEME_WAVE[th], muls[idx(Cfg.WAVES, 3)],
                idx(Cfg.BGPRESET, Art.NAMES.length), idx(Cfg.BGVAR, 6),
                st >= 4 ? wallpaper : null, dim, ds);

        if (st < 4 && wallpaper != null) releaseWallpaper(); // освобождаем память
    }

    private void releaseWallpaper() {
        if (wallpaper != null) {
            Bitmap old = wallpaper;
            wallpaper = null;
            old.recycle();
        }
    }

    // Следующие обои (синяя кнопка на пульте или пункт в настройках)
    private void advanceWallpaper() {
        if (perf == 2) { toast("В минимальном режиме обои отключены"); return; }
        int st = idx(Cfg.BGSTYLE, 7);
        if (st < 3) {
            int n = Cfg.THEME_NAMES.length;
            int t = (idx(Cfg.THEME, n) + 1) % n;
            cfg.set(Cfg.THEME, t);
            updateBg();
            toast("Тема: " + Cfg.THEME_NAMES[t]);
        } else if (st == 3) {
            int n = Art.NAMES.length;
            int p = (idx(Cfg.BGPRESET, n) + 1) % n;
            cfg.set(Cfg.BGPRESET, p);
            updateBg();
            toast(Art.NAMES[p]);
        } else if (st == 4) {
            cfg.putInt("file_idx", cfg.getInt("file_idx", 0) + 1);
            loadPhoto(false, true);
        } else {
            toast("Загружаю новые обои…");
            loadPhoto(true, true);
        }
    }

    private void maybeAutoWallpaper(boolean created) {
        int mode = idx(Cfg.WPAUTO, 3);
        if (mode == 0 || perf == 2) return;
        if (idx(Cfg.BGSTYLE, 7) < 3) return;
        long now = System.currentTimeMillis();
        long last = cfg.getLong("auto_t", 0L);
        boolean due = mode == 1 ? created : (now - last > 24L * 3600L * 1000L);
        if (!due) return;
        cfg.putLong("auto_t", now);
        advanceWallpaper();
    }

    // Фото-обои: из файлов, Bing или случайные. Всегда обрезаются под размер экрана
    private void loadPhoto(final boolean force, boolean userAction) {
        final int st = idx(Cfg.BGSTYLE, 7);
        if (st < 4 || perf == 2 || photoLoading) return;
        if (st == 4 && Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (userAction) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
            }
            return;
        }
        photoLoading = true;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int tw = perf == 0 ? dm.widthPixels : dm.widthPixels / 2;
        final int th = perf == 0 ? dm.heightPixels : dm.heightPixels / 2;

        new Thread(new Runnable() {
            @Override public void run() {
                File f = (st == 4) ? pickLocalFile() : netFile(st, force);
                final Bitmap bmp = (f != null) ? decodeCover(f.getAbsolutePath(), tw, th) : null;
                final String msg = (f == null)
                        ? (st == 4 ? "Нет картинок: положите launcher_bg.jpg в папку Download"
                                   : "Не удалось загрузить обои. Проверьте интернет")
                        : "Не удалось открыть картинку";
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        photoLoading = false;
                        if (bmp == null) { toast(msg); return; }
                        if (idx(Cfg.BGSTYLE, 7) < 4) { bmp.recycle(); return; }
                        Bitmap old = wallpaper;
                        wallpaper = bmp;
                        updateBg();
                        if (old != null) old.recycle();
                    }
                });
            }
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_STORAGE) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            loadPhoto(false, false);
        } else {
            toast("Нет доступа к файлам. Разрешите в Настройки → Приложения → Лаунчер → Разрешения");
        }
    }

    // Файлы launcher_bg*.jpg/png из Download и любые картинки из Download/launcher_wallpapers
    private File pickLocalFile() {
        List<File> files = new ArrayList<File>();
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        addImages(files, dir, true);
        addImages(files, new File(dir, "launcher_wallpapers"), false);
        if (files.isEmpty()) return null;
        Collections.sort(files);
        int n = files.size();
        int i = ((cfg.getInt("file_idx", 0) % n) + n) % n;
        return files.get(i);
    }

    private static void addImages(List<File> out, File dir, boolean onlyPrefixed) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (!f.isFile()) continue;
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (!(n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png"))) continue;
            if (onlyPrefixed && !n.startsWith("launcher_bg")) continue;
            out.add(f);
        }
    }

    // Обои из интернета: Bing (обои дня) или случайное фото. Кэшируются внутри приложения
    private File netFile(int st, boolean force) {
        File f = new File(getFilesDir(), st == 5 ? "bg_bing.jpg" : "bg_random.jpg");
        boolean stale = !f.exists()
                || System.currentTimeMillis() - f.lastModified() > 20L * 3600L * 1000L;
        if (force || stale) {
            try {
                String url;
                if (st == 5) {
                    int bi = force ? new Random().nextInt(8) : 0;
                    String js = Net.getString("https://www.bing.com/HPImageArchive.aspx?format=js&idx="
                            + bi + "&n=1&mkt=ru-RU");
                    String rel = new JSONObject(js).getJSONArray("images")
                            .getJSONObject(0).getString("url");
                    url = rel.startsWith("http") ? rel : "https://www.bing.com" + rel;
                } else {
                    url = "https://picsum.photos/1280/720?random=" + System.currentTimeMillis();
                }
                Net.download(url, f);
            } catch (Throwable ignored) { }
        }
        return f.exists() ? f : null;
    }

    private static Bitmap decodeCover(String path, int tw, int th) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= tw && o.outHeight / (sample * 2) >= th) {
                sample *= 2;
            }
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap src = BitmapFactory.decodeFile(path, o);
            if (src == null) return null;

            Bitmap out = Bitmap.createBitmap(tw, th, Bitmap.Config.RGB_565);
            float s = Math.max((float) tw / src.getWidth(), (float) th / src.getHeight());
            float dx = (tw - src.getWidth() * s) / 2f;
            float dy = (th - src.getHeight() * s) / 2f;
            Canvas c = new Canvas(out);
            c.translate(dx, dy);
            c.scale(s, s);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
            p.setDither(true);
            c.drawBitmap(src, 0, 0, p);
            src.recycle();
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    // ============================================================ избранное

    private boolean isFav(String pkg) { return cfg.list(LIST_FAVS).contains(pkg); }

    private boolean toggleFav(App a) {
        List<String> l = cfg.list(LIST_FAVS);
        boolean now;
        if (l.contains(a.pkg)) { l.remove(a.pkg); now = false; }
        else { l.add(a.pkg); now = true; }
        cfg.saveList(LIST_FAVS, l);
        return now;
    }

    private void onFavChanged(App a) {
        refreshRow(FOCUS_NONE);
        TextView st = stars.get(a.pkg);
        if (st != null) st.setVisibility(isFav(a.pkg) ? View.VISIBLE : View.GONE);
        toast(isFav(a.pkg) ? "Добавлено в избранное: " + a.label
                           : "Убрано из избранного: " + a.label);
    }

    private void moveFav(App a, int dir) {
        List<String> l = cfg.list(LIST_FAVS);
        int i = l.indexOf(a.pkg);
        int j = i + dir;
        if (i < 0 || j < 0 || j >= l.size()) { toast("Дальше нельзя"); return; }
        Collections.swap(l, i, j);
        cfg.saveList(LIST_FAVS, l);
        refreshRow(FOCUS_NONE);
        focusTile(a.pkg);
    }

    private void hideApp(App a) {
        List<String> hidden = cfg.list(LIST_HIDDEN);
        if (!hidden.contains(a.pkg)) hidden.add(a.pkg);
        cfg.saveList(LIST_HIDDEN, hidden);
        List<String> favs = cfg.list(LIST_FAVS);
        favs.remove(a.pkg);
        cfg.saveList(LIST_FAVS, favs);
        toast("Скрыто: " + a.label + " (вернуть: Настройки → Показать скрытые)");
        refreshRow(FOCUS_NONE);
        if (allOverlay != null) {
            closeAll(false);
            openAll();
        }
    }

    private void fillDefaultFavs() {
        List<String> favs = new ArrayList<String>();
        for (String p : DEFAULT_FAVS) {
            if (find(p) != null) favs.add(p);
        }
        cfg.saveList(LIST_FAVS, favs);
    }

    private App find(String pkg) {
        for (App a : apps) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    private void launch(App a) {
        cfg.inc(a.pkg);
        try { startActivity(a.intent); }
        catch (Exception e) { toast("Не удалось открыть " + a.label); }
    }

    // Меню по долгому нажатию OK на приложении
    private void showAppMenu(final App a) {
        final boolean fav = isFav(a.pkg);
        final List<String> names = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();

        names.add(fav ? "Убрать из избранного" : "Добавить в избранное");
        acts.add(() -> { toggleFav(a); onFavChanged(a); });

        if (fav) {
            names.add("Сдвинуть влево");
            acts.add(() -> moveFav(a, -1));
            names.add("Сдвинуть вправо");
            acts.add(() -> moveFav(a, 1));
        }

        names.add("Скрыть из списка");
        acts.add(() -> hideApp(a));

        names.add("О приложении");
        acts.add(() -> safeStart(new Intent(
                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.pkg))));

        if (!a.system) {
            names.add("Удалить");
            acts.add(() -> safeStart(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))));
        }

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.label)
                .setItems(names.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void confirm(String msg, final Runnable yes) {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setMessage(msg)
                .setPositiveButton("Да", (d, w) -> yes.run())
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ========================================================= все приложения

    private void openAll() {
        if (allOverlay != null || settingsOverlay != null) return;

        List<App> list = new ArrayList<App>();
        List<String> hidden = cfg.list(LIST_HIDDEN);
        for (App a : apps) {
            if (!hidden.contains(a.pkg)) list.add(a);
        }
        int sort = idx(Cfg.ALL_SORT, 3);
        if (sort == 1) {
            Collections.reverse(list);
        } else if (sort == 2) {
            Collections.sort(list, new Comparator<App>() {
                @Override public int compare(App x, App y) {
                    int c = cfg.count(y.pkg) - cfg.count(x.pkg);
                    return c != 0 ? c : x.label.compareToIgnoreCase(y.label);
                }
            });
        }

        int th = idx(Cfg.THEME, Cfg.THEME_BG.length);
        allOverlay = new LinearLayout(this);
        allOverlay.setOrientation(LinearLayout.VERTICAL);
        allOverlay.setBackgroundColor((0xF0 << 24) | (Cfg.THEME_BG[th][0] & 0x00FFFFFF));
        allOverlay.setClickable(true);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(px(5f), px(3f), px(5f), px(1f));
        head.addView(text("Все приложения · " + list.size(), 3.4f, Color.WHITE));
        head.addView(text("Удерживайте OK на приложении — меню (избранное, скрыть, удалить)",
                1.5f, 0x99FFFFFF));
        allOverlay.addView(head, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipChildren(false);
        sv.setClipToPadding(false);
        sv.setPadding(px(4.4f), px(1.5f), px(4.4f), px(3f));

        int cols = 4 + idx(Cfg.ALL_COLS, 4);
        GridLayout gl = new GridLayout(this);
        gl.setColumnCount(cols);
        gl.setClipChildren(false);

        int cw = px((100f - 8.8f - cols * 1.2f) / cols);
        int ch = Math.round(cw * 0.62f);
        int m = px(0.6f);
        stars.clear();

        for (final App a : list) {
            FrameLayout t = tile(a, cw, ch, false);
            TextView star = text("★", 2.2f, 0xFFFFD54F);
            FrameLayout.LayoutParams sp2 = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.END);
            sp2.setMargins(0, px(0.4f), px(0.8f), 0);
            t.addView(star, sp2);
            star.setVisibility(isFav(a.pkg) ? View.VISIBLE : View.GONE);
            stars.put(a.pkg, star);

            t.setOnClickListener(v -> launch(a));
            t.setOnLongClickListener(v -> { showAppMenu(a); return true; });

            GridLayout.LayoutParams glp = new GridLayout.LayoutParams();
            glp.width = cw;
            glp.height = ch;
            glp.setMargins(m, m, m, m);
            gl.addView(t, glp);
        }

        sv.addView(gl, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        allOverlay.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(allOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        home.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (gl.getChildCount() > 0) gl.getChildAt(0).requestFocus();
    }

    private void closeAll(boolean focusRow) {
        if (allOverlay == null) return;
        root.removeView(allOverlay);
        allOverlay = null; // освобождаем память
        stars.clear();
        home.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (focusRow) refreshRow(FOCUS_ALL);
    }

    // ============================================================= настройки

    private Drawable rowBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(0x33FFFFFF);
        on.setCornerRadius(0.8f * u);
        on.setStroke(Math.max(2, Math.round(0.2f * u)), accent);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return sl;
    }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = px(0.3f);
        return lp;
    }

    private void openSettings() {
        if (settingsOverlay != null || allOverlay != null) return;
        settingsOverlay = new FrameLayout(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xF2101624);
        panel.setPadding(px(2f), px(2.5f), px(1.5f), px(1f));
        panel.addView(text("Настройки", 3f, Color.WHITE));
        panel.addView(text("← → меняют значение, OK — следующее или список, Назад — закрыть",
                1.3f, 0x99FFFFFF));
        panel.addView(text("Пульт: красная — все приложения, зелёная — настройки, "
                + "жёлтая — очистка памяти, синяя — следующие обои", 1.2f, 0x77FFFFFF));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setPadding(0, px(1f), px(0.5f), px(2f));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        View firstRow = null;
        for (Cfg.Opt o : Cfg.OPTS) {
            if (o.isHeader()) {
                list.addView(sectionTitle(o.title));
            } else {
                View r = optRow(o);
                if (firstRow == null) firstRow = r;
                list.addView(r, rowLp());
            }
        }

        list.addView(sectionTitle("ДЕЙСТВИЯ"));
        list.addView(actionRow("Следующие обои", () -> advanceWallpaper()), rowLp());
        list.addView(actionRow("Обновить обои из интернета", () -> {
            int st = idx(Cfg.BGSTYLE, 7);
            if (st >= 5) {
                toast("Загружаю новые обои…");
                loadPhoto(true, true);
            } else {
                toast("Выберите «Фон → Bing» или «Случайные фото»");
            }
        }), rowLp());
        list.addView(actionRow("Очистить память сейчас", () -> cleanMemory()), rowLp());
        list.addView(actionRow("Обновить погоду", () -> {
            if (idx(Cfg.WEATHER, Cfg.CITY_NAMES.length + 1) == 0) toast("Сначала выберите город");
            else fetchWeather(true);
        }), rowLp());

        list.addView(sectionTitle("ДАННЫЕ"));
        list.addView(actionRow("Сбросить избранное к стандартному", () -> confirm(
                "Сбросить избранное к стандартному набору?", () -> {
                    cfg.remove(LIST_FAVS);
                    fillDefaultFavs();
                    refreshRow(FOCUS_NONE);
                    toast("Избранное сброшено");
                })), rowLp());
        list.addView(actionRow("Показать скрытые приложения", () -> {
            cfg.remove(LIST_HIDDEN);
            toast("Скрытые приложения возвращены");
        }), rowLp());
        list.addView(actionRow("Сбросить все настройки вида", () -> confirm(
                "Вернуть стандартные настройки вида?", () -> {
                    cfg.resetOptions();
                    releaseWallpaper();
                    applyAll();
                    closeSettings(false);
                    openSettings();
                })), rowLp());

        sv.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        settingsOverlay.addView(panel, new FrameLayout.LayoutParams(
                px(42f), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));
        root.addView(settingsOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        home.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (firstRow != null) firstRow.requestFocus();
    }

    private void closeSettings(boolean focusRow) {
        if (settingsOverlay == null) return;
        root.removeView(settingsOverlay);
        settingsOverlay = null;
        home.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (focusRow) refreshRow(FOCUS_ALL);
    }

    private TextView sectionTitle(String s) {
        TextView hd = text(s, 1.4f, accent);
        hd.setPadding(px(0.5f), px(1.6f), 0, px(0.4f));
        return hd;
    }

    private View actionRow(String title, final Runnable action) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));
        r.addView(text(title, 1.8f, Color.WHITE));
        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> action.run());
        return r;
    }

    private View optRow(final Cfg.Opt o) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));

        TextView t = text(o.title, 1.8f, Color.WHITE);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text("", 1.8f, accent);
        r.addView(val);
        setValueText(val, o);

        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        // Если значений много, OK открывает список; иначе переключает на следующее
        r.setOnClickListener(x -> {
            if (o.labels.length > 6) pickOpt(o, val);
            else changeOpt(o, val, 1);
        });
        r.setOnKeyListener((x, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) { changeOpt(o, val, 1); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { changeOpt(o, val, -1); return true; }
            return false;
        });
        return r;
    }

    private void setValueText(TextView val, Cfg.Opt o) {
        val.setText("‹ " + o.labels[idx(o.key, o.labels.length)] + " ›");
    }

    private void changeOpt(Cfg.Opt o, TextView val, int dir) {
        int n = o.labels.length;
        int next = (idx(o.key, n) + dir + n) % n;
        cfg.set(o.key, next);
        setValueText(val, o);
        onOptChanged(o.key, next);
    }

    private void pickOpt(final Cfg.Opt o, final TextView val) {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(o.title)
                .setItems(o.labels, (d, which) -> {
                    cfg.set(o.key, which);
                    setValueText(val, o);
                    onOptChanged(o.key, which);
                })
                .show();
    }

    // Применить изменение сразу (за панелью настроек видно результат)
    private void onOptChanged(String key, int value) {
        if (key.startsWith("clock_")) {
            applyClock();
        } else if (key.equals(Cfg.THEME) || key.startsWith("bg_")) {
            if (key.equals(Cfg.BGSTYLE) && value >= 4) loadPhoto(false, true);
            updateBg();
        } else if (key.startsWith("info_")) {
            applyInfo();
            if (key.equals(Cfg.WEATHER)) fetchWeather(true);
        } else if (key.equals(Cfg.PERF)) {
            releaseWallpaper(); // качество обоев зависит от режима
            applyAll();
            if (idx(Cfg.BGSTYLE, 7) >= 4) loadPhoto(false, false);
        } else if (key.startsWith("all_") || key.equals(Cfg.AUTOSTART)) {
            // применится при следующем открытии списка / запуске
        } else {
            applyLook();
        }
    }

    // ============================================= загрузка списка приложений

    private void loadApps() {
        if (loading) return;
        loading = true;
        new Thread(new Runnable() {
            @Override public void run() {
                final List<App> result = queryApps();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        loading = false;
                        StringBuilder sb = new StringBuilder();
                        for (App a : result) sb.append(a.pkg).append('|').append(a.label).append(';');
                        String sig = sb.toString();
                        if (sig.equals(lastSig)) return; // ничего не изменилось
                        boolean initial = lastSig.isEmpty();
                        lastSig = sig;
                        apps.clear();
                        apps.addAll(result);
                        bannerCache.clear();

                        if (!cfg.has(LIST_FAVS)) fillDefaultFavs(); // первый запуск
                        if (allOverlay == null && settingsOverlay == null) {
                            refreshRow(initial ? 0 : FOCUS_NONE);
                        }
                        if (initial) tryAutostart();
                    }
                });
            }
        }).start();
    }

    // Автозапуск первого избранного приложения после включения приставки
    private void tryAutostart() {
        if (autoDone) return;
        autoDone = true;
        if (idx(Cfg.AUTOSTART, 2) != 1) return;
        if (SystemClock.elapsedRealtime() > 180000L) return; // только вскоре после включения
        for (String p : cfg.list(LIST_FAVS)) {
            App a = find(p);
            if (a != null) { launch(a); return; }
        }
    }

    private List<App> queryApps() {
        List<App> out = new ArrayList<App>();
        Set<String> seen = new HashSet<String>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};

        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.ai = ri.activityInfo;
                a.label = String.valueOf(ri.loadLabel(pm));
                // Иконка сразу уменьшается до маленькой картинки: экономит память
                Bitmap ib = iconBitmap(ri.loadIcon(pm));
                a.icon = new BitmapDrawable(getResources(), ib);
                a.color = dominant(ib);
                a.system = (ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                a.intent = new Intent(Intent.ACTION_MAIN)
                        .addCategory(cat)
                        .setComponent(new ComponentName(pkg, ri.activityInfo.name))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                out.add(a);
            }
        }
        final Collator col = Collator.getInstance();
        Collections.sort(out, new Comparator<App>() {
            @Override public int compare(App x, App y) { return col.compare(x.label, y.label); }
        });
        return out;
    }

    private static Bitmap iconBitmap(Drawable d) {
        Bitmap b = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, ICON_PX, ICON_PX);
        d.draw(c);
        return b;
    }

    // Средний цвет иконки (для подкраски плитки)
    private static int dominant(Bitmap b) {
        final int fallback = 0xFF2A3350;
        try {
            Bitmap t = Bitmap.createScaledBitmap(b, 8, 8, true);
            long r = 0, g = 0, bl = 0, n = 0;
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 8; x++) {
                    int p = t.getPixel(x, y);
                    if (Color.alpha(p) < 128) continue;
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                    n++;
                }
            }
            if (t != b) t.recycle();
            if (n == 0) return fallback;
            return Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n));
        } catch (Throwable ex) {
            return fallback;
        }
    }

    // ========================================================= жизненный цикл

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        if (!firstStart) {
            loadApps(); // вернулись на главный экран: проверим список
            maybeAutoWallpaper(false);
            if (idx(Cfg.NIGHT, 2) == 1 && isNight() != lastNight) updateBg();
        }
        firstStart = false;

        applyInfo();
        updateRamTile();
        fetchWeather(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) { }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Нажатие Home: закрыть списки и вернуться в начало ряда
        closeSettings(false);
        closeAll(false);
        rowScroll.scrollTo(0, 0);
        if (row.getChildCount() > 0) row.getChildAt(0).requestFocus();
        applyInfo();
        updateRamTile();
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_PROG_GREEN:
                openSettings();
                return true;
            case KeyEvent.KEYCODE_PROG_RED:
                openAll();
                return true;
            case KeyEvent.KEYCODE_PROG_YELLOW:
                cleanMemory();
                return true;
            case KeyEvent.KEYCODE_PROG_BLUE:
                advanceWallpaper();
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }

    @Override
    public void onBackPressed() {
        if (settingsOverlay != null) closeSettings(true);
        else if (allOverlay != null) closeAll(true);
        // на главном экране «Назад» ничего не делает
    }
}
