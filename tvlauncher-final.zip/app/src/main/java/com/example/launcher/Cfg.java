package com.example.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Хранилище настроек и список всех пунктов меню настроек.
 * Чтобы добавить новую настройку: допиши строку в OPTS и обработай её в MainActivity.
 */
final class Cfg {

    // ---- ключи настроек ----
    static final String THEME = "theme", ACCENT = "accent";
    static final String BGSTYLE = "bg_style", BGPRESET = "bg_preset", BGVAR = "bg_var",
            WPAUTO = "bg_auto", WAVES = "bg_waves", BGDIM = "bg_dim", NIGHT = "bg_night";
    static final String CLOCK_SHOW = "clock_show", CLOCK_FMT = "clock_fmt",
            CLOCK_SIZE = "clock_size", CLOCK_POS = "clock_pos", CLOCK_FONT = "clock_font",
            CLOCK_DATE = "clock_date";
    static final String GREETING = "info_greet", WEATHER = "info_weather", RAMSHOW = "info_ram";
    static final String TILE_SIZE = "tile_size", TILE_RATIO = "tile_ratio",
            TILE_ROUND = "tile_round", TILE_GAP = "tile_gap", TILE_BANNERS = "tile_banners",
            TILE_LABELS = "tile_labels", TILE_TINT = "tile_tint", TILE_TOOLS = "tile_tools";
    static final String ROW_POS = "row_pos", ALL_POS = "row_all";
    static final String FOCUS_SCALE = "focus_scale", FOCUS_BORDER = "focus_border",
            FOCUS_ANIM = "focus_anim";
    static final String ALL_COLS = "all_cols", ALL_SORT = "all_sort";
    static final String PERF = "perf", AUTOSTART = "autostart";

    // ---- цветовые темы: три цвета фона и три цвета волн ----
    static final String[] THEME_NAMES = {
            "Ночь", "Океан", "Закат", "Лес", "Роза", "Графит", "Чёрный"
    };
    static final int[][] THEME_BG = {
            {0xFF080D1C, 0xFF17123D, 0xFF0A2C3C}, // Ночь
            {0xFF04121F, 0xFF06344F, 0xFF0B5C6B}, // Океан
            {0xFF1A0B1E, 0xFF4A1942, 0xFF7A2E2E}, // Закат
            {0xFF06140E, 0xFF0E3B26, 0xFF1D4A2A}, // Лес
            {0xFF1C0A16, 0xFF4A1235, 0xFF2B1250}, // Роза
            {0xFF101214, 0xFF1B1F24, 0xFF262B32}, // Графит
            {0xFF000000, 0xFF000000, 0xFF000000}  // Чёрный
    };
    static final int[][] THEME_WAVE = {
            {0xFF4FD1FF, 0xFF8E6BFF, 0xFF3A8DFF},
            {0xFF5EEAD4, 0xFF38BDF8, 0xFF22D3EE},
            {0xFFFB923C, 0xFFF472B6, 0xFFFACC15},
            {0xFF4ADE80, 0xFFA3E635, 0xFF2DD4BF},
            {0xFFF472B6, 0xFFC084FC, 0xFFFB7185},
            {0xFF94A3B8, 0xFF64748B, 0xFFCBD5E1},
            {0xFF4FD1FF, 0xFF8E6BFF, 0xFF3A8DFF}
    };
    // Голубой, Фиолетовый, Розовый, Оранжевый, Зелёный, Красный, Белый
    static final int[] ACCENTS = {
            0xFF38BDF8, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316, 0xFF22C55E, 0xFFEF4444, 0xFFFFFFFF
    };

    // ---- города для погоды (названия и координаты) ----
    static final String[] CITY_NAMES = {
            "Алматы", "Астана", "Шымкент", "Москва", "Санкт-Петербург", "Новосибирск",
            "Екатеринбург", "Киев", "Минск", "Ташкент", "Бишкек", "Баку", "Тбилиси",
            "Ереван", "Стамбул", "Дубай", "Берлин", "Лондон", "Нью-Йорк"
    };
    static final double[] CITY_LAT = {
            43.25, 51.18, 42.32, 55.75, 59.93, 55.03, 56.84, 50.45, 53.90, 41.30,
            42.87, 40.41, 41.72, 40.18, 41.01, 25.20, 52.52, 51.51, 40.71
    };
    static final double[] CITY_LON = {
            76.95, 71.45, 69.59, 37.62, 30.34, 82.92, 60.60, 30.52, 27.57, 69.24,
            74.59, 49.87, 44.79, 44.51, 28.98, 55.27, 13.41, -0.13, -74.01
    };

    // ---- описание пунктов меню ----
    static final class Opt {
        final String key;
        final String title;
        final int def;
        final String[] labels;

        Opt(String key, String title, int def, String... labels) {
            this.key = key;
            this.title = title;
            this.def = def;
            this.labels = labels;
        }

        boolean isHeader() { return key == null; }
    }

    private static Opt h(String title) { return new Opt(null, title, 0); }

    private static Opt o(String key, String title, int def, String... labels) {
        return new Opt(key, title, def, labels);
    }

    private static String[] withOff(String[] names) {
        String[] r = new String[names.length + 1];
        r[0] = "Выкл";
        System.arraycopy(names, 0, r, 1, names.length);
        return r;
    }

    static final Opt[] OPTS = {
            h("ТЕМА"),
            o(THEME, "Цветовая тема", 0, THEME_NAMES),
            o(ACCENT, "Акцентный цвет", 0, "Голубой", "Фиолетовый", "Розовый", "Оранжевый", "Зелёный", "Красный", "Белый"),

            h("ФОН И ОБОИ"),
            o(BGSTYLE, "Фон", 0, "Волны", "Градиент", "Однотонный", "Встроенные обои",
                    "Свои фото (файлы)", "Bing — обои дня", "Случайные фото"),
            o(BGPRESET, "Встроенные обои", 0, Art.NAMES),
            o(BGVAR, "Вариант обоев", 0, "1", "2", "3", "4", "5", "6"),
            o(WPAUTO, "Автосмена обоев", 0, "Вручную", "При запуске", "Раз в сутки"),
            o(WAVES, "Яркость волн", 1, "Слабые", "Обычные", "Яркие"),
            o(BGDIM, "Затемнение фона", 0, "Нет", "20%", "40%", "60%"),
            o(NIGHT, "Ночью (22:00–07:00)", 0, "Без изменений", "Затемнять"),

            h("ЧАСЫ И ИНФОРМАЦИЯ"),
            o(CLOCK_SHOW, "Часы", 0, "Показывать", "Скрыть"),
            o(CLOCK_FMT, "Формат времени", 0, "24 часа", "12 часов"),
            o(CLOCK_SIZE, "Размер часов", 1, "Малые", "Средние", "Крупные", "Огромные"),
            o(CLOCK_POS, "Положение часов", 0, "Слева", "По центру", "Справа"),
            o(CLOCK_FONT, "Шрифт часов", 1, "Тонкий", "Лёгкий", "Обычный", "Жирный"),
            o(CLOCK_DATE, "Дата", 0, "Показывать", "Скрыть"),
            o(GREETING, "Приветствие", 1, "Выкл", "Вкл"),
            o(WEATHER, "Погода", 0, withOff(CITY_NAMES)),
            o(RAMSHOW, "Свободная память", 1, "Выкл", "Вкл"),

            h("ПЛИТКИ ИЗБРАННОГО"),
            o(TILE_SIZE, "Размер плиток", 1, "Мелкие", "Средние", "Крупные"),
            o(TILE_RATIO, "Пропорции", 0, "16:9", "4:3", "Квадрат"),
            o(TILE_ROUND, "Скругление углов", 2, "Острые", "Малое", "Среднее", "Большое"),
            o(TILE_GAP, "Расстояние между плитками", 1, "Малое", "Среднее", "Большое"),
            o(TILE_BANNERS, "Баннеры приложений", 0, "Показывать", "Не показывать"),
            o(TILE_LABELS, "Подписи на плитках", 0, "Показывать", "Скрыть"),
            o(TILE_TINT, "Цвет плиток без баннера", 0, "По иконке", "Тёмный", "Акцентный"),
            o(ROW_POS, "Положение ряда", 0, "Внизу", "Выше", "По центру"),
            o(ALL_POS, "Плитка «Все приложения»", 1, "В начале ряда", "В конце ряда"),
            o(TILE_TOOLS, "Плитка очистки памяти", 0, "Показывать", "Скрыть"),

            h("ВЫДЕЛЕНИЕ"),
            o(FOCUS_SCALE, "Увеличение выбранной", 2, "Нет", "Малое", "Среднее", "Большое"),
            o(FOCUS_BORDER, "Рамка выбранной", 1, "Нет", "Белая", "Акцентная"),
            o(FOCUS_ANIM, "Скорость анимации", 1, "Быстро", "Обычно", "Плавно", "Без анимации"),

            h("СПИСОК «ВСЕ ПРИЛОЖЕНИЯ»"),
            o(ALL_COLS, "Колонок", 1, "4", "5", "6", "7"),
            o(ALL_SORT, "Сортировка", 0, "А → Я", "Я → А", "Частые сверху"),

            h("СИСТЕМА"),
            o(PERF, "Режим производительности", 0, "Обычный", "Лёгкий", "Минимальный"),
            o(AUTOSTART, "Автозапуск при включении", 0, "Выкл", "Первое избранное")
    };

    private final SharedPreferences sp;

    Cfg(Context c) {
        sp = c.getSharedPreferences("launcher_pro", Context.MODE_PRIVATE);
    }

    // ---- пункты меню (индекс выбранного значения) ----
    int get(String key) { return sp.getInt(key, defOf(key)); }

    void set(String key, int v) { sp.edit().putInt(key, v).apply(); }

    private static int defOf(String key) {
        for (Opt op : OPTS) {
            if (key.equals(op.key)) return op.def;
        }
        return 0;
    }

    // ---- произвольные значения ----
    int getInt(String key, int def) { return sp.getInt(key, def); }

    void putInt(String key, int v) { sp.edit().putInt(key, v).apply(); }

    long getLong(String key, long def) { return sp.getLong(key, def); }

    void putLong(String key, long v) { sp.edit().putLong(key, v).apply(); }

    boolean has(String key) { return sp.contains(key); }

    void remove(String key) { sp.edit().remove(key).apply(); }

    // Списки (избранное, скрытые приложения): пакеты через перевод строки
    List<String> list(String key) {
        String s = sp.getString(key, "");
        List<String> l = new ArrayList<String>();
        if (s != null && !s.isEmpty()) {
            for (String x : s.split("\n")) {
                if (!x.isEmpty()) l.add(x);
            }
        }
        return l;
    }

    void saveList(String key, List<String> l) {
        sp.edit().putString(key, TextUtils.join("\n", l)).apply();
    }

    // Счётчик запусков для сортировки «Частые сверху»
    int count(String pkg) { return sp.getInt("n_" + pkg, 0); }

    void inc(String pkg) { sp.edit().putInt("n_" + pkg, count(pkg) + 1).apply(); }

    void resetOptions() {
        SharedPreferences.Editor e = sp.edit();
        for (Opt op : OPTS) {
            if (!op.isHeader()) e.remove(op.key);
        }
        e.apply();
    }
}
