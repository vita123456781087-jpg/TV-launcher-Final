package com.example.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Лёгкие самодельные иконки без картинок. */
final class Widgets {

    private Widgets() { }

    /** Иконка «сетка 2x2» для плитки «Все приложения». */
    static final class GridIcon extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        GridIcon(Context c, int color) {
            super(c);
            p.setColor(color);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float g = w * 0.1f;
            float s = (w - g) / 2f;
            float r = s * 0.24f;
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    float x = j * (s + g);
                    float y = i * (s + g);
                    c.drawRoundRect(x, y, x + s, y + s, r, r, p);
                }
            }
        }
    }

    /** Иконка «ползунки» для кнопки настроек. */
    static final class SlidersIcon extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        SlidersIcon(Context c) {
            super(c);
            p.setColor(0xFFFFFFFF);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float[] ys = {h * 0.2f, h * 0.5f, h * 0.8f};
            float[] kx = {w * 0.3f, w * 0.7f, w * 0.45f};
            p.setStrokeWidth(h * 0.07f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 3; i++) {
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(w * 0.05f, ys[i], w * 0.95f, ys[i], p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(kx[i], ys[i], h * 0.11f, p);
            }
        }
    }

    /** Кольцо занятой оперативной памяти для плитки очистки. */
    static final class RamGauge extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private float used = 0.5f;

        RamGauge(Context c) {
            super(c);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        void setUsed(float fraction) {
            used = Math.max(0f, Math.min(1f, fraction));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float sw = w * 0.14f;
            p.setStrokeWidth(sw);
            rect.set(sw / 2f, sw / 2f, w - sw / 2f, w - sw / 2f);
            p.setColor(0x33FFFFFF);
            c.drawArc(rect, 0, 360, false, p);
            int col = used < 0.6f ? 0xFF4ADE80 : (used < 0.8f ? 0xFFFBBF24 : 0xFFF87171);
            p.setColor(col);
            c.drawArc(rect, -90, 360f * used, false, p);
        }
    }
}
