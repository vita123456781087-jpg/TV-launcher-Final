package com.example.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Минимальные сетевые функции. Вызывать только из фонового потока. */
final class Net {

    private Net() { }

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 9) TvLauncher");
        return c;
    }

    /** Загрузить небольшой текст (JSON), не более 200 КБ. */
    static String getString(String url) throws Exception {
        HttpURLConnection c = open(url);
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            int total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 200 * 1024) throw new Exception("too big");
                out.write(buf, 0, n);
            }
            in.close();
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    /** Скачать файл (не более 8 МБ). Старый файл заменяется только при успехе. */
    static boolean download(String url, File dest) {
        File tmp = new File(dest.getPath() + ".tmp");
        HttpURLConnection c = null;
        try {
            c = open(url);
            if (c.getResponseCode() != 200) return false;
            InputStream in = c.getInputStream();
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 8L * 1024 * 1024) {
                    out.close();
                    in.close();
                    tmp.delete();
                    return false;
                }
                out.write(buf, 0, n);
            }
            out.close();
            in.close();
            if (total < 10 * 1024) {
                tmp.delete();
                return false;
            }
            if (dest.exists()) dest.delete();
            return tmp.renameTo(dest);
        } catch (Throwable t) {
            tmp.delete();
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
