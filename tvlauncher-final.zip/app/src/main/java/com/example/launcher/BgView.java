package com.example.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

/**
 * Фон главного экрана. Картинка готовится один раз (в уменьшенном размере),
 * а при отрисовке выводится одним вызовом: это максимально лёгкий вариант для слабого GPU.
 */
final class BgView extends View {

    private final Paint bmpP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect dst = new Rect();

    private Bitmap cache;   // готовый фон (RGB_565, уменьшенный), принадлежит этому View
    private Bitmap photo;   // фото-обои по размеру экрана, принадлежат MainActivity

    private int style = 1;  // 0 волны, 1 градиент, 2 однотонный, 3 встроенные, 4+ фото
    private int[] bg = {0xFF000000, 0xFF000000, 0xFF000000};
    private int[] wave = {0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF};
    private float mul = 1f;
    private int preset = 0;
    private int variant = 0;
    private int dim = 0;    // затемнение, %
    private int ds = 2;     // во сколько раз уменьшать картинку фона
    private int vw, vh;

    BgView(Context c) {
        super(c);
    }

    void apply(int style, int[] bg, int[] wave, float mul, int preset, int variant,
               Bitmap photo, int dimPercent, int downscale) {
        this.style = style;
        this.bg = bg;
        this.wave = wave;
        this.mul = mul;
        this.preset = preset;
        this.variant = variant;
        this.photo = photo;
        this.dim = dimPercent;
        this.ds = Math.max(1, downscale);
        rebuild();
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        vw = w;
        vh = h;
        dst.set(0, 0, w, h);
        rebuild();
    }

    private boolean photoOk() {
        return style >= 4 && photo != null && !photo.isRecycled();
    }

    private void rebuild() {
        if (vw <= 0 || vh <= 0) return;
        Bitmap old = cache;
        cache = null;
        int alpha = Math.max(0, Math.min(255, dim * 255 / 100));

        if (style == 2) {
            // однотонный: рисуется заливкой, картинка не нужна
        } else if (photoOk()) {
            if (dim > 0) { // фото с затемнением: готовим копию
                cache = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(),
                        Bitmap.Config.RGB_565);
                Canvas cv = new Canvas(cache);
                cv.drawBitmap(photo, 0, 0, null);
                cv.drawColor(Color.argb(alpha, 0, 0, 0));
            }
            // без затемнения фото рисуется напрямую
        } else {
            int st = style >= 4 ? 1 : style; // фото ещё грузится: пока градиент
            int cw = Math.max(2, vw / ds);
            int ch = Math.max(2, vh / ds);
            cache = Art.make(st, preset, variant, bg, wave, mul, cw, ch);
            if (dim > 0) new Canvas(cache).drawColor(Color.argb(alpha, 0, 0, 0));
        }
        if (old != null) old.recycle();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (vw <= 0 || vh <= 0) return;
        if (style == 2) {
            c.drawColor(bg[1]);
            return;
        }
        Bitmap src = cache != null ? cache : (photoOk() ? photo : null);
        if (src != null) c.drawBitmap(src, null, dst, bmpP);
    }
}
